<?php
$number = 10;

while ($number >= 1) {
    echo $number . PHP_EOL;
    $number--;
}

echo "Liftoff!";
