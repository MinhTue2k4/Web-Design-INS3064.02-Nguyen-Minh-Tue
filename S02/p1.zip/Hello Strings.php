<?php
echo "Enter name: ";
$name = trim(fgets(STDIN));

echo "Enter city: ";
$city = trim(fgets(STDIN));

echo $name . " lives in " . $city . ".";

